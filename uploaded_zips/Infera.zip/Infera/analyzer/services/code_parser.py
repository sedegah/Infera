import os
import zipfile
import tempfile
from typing import Tuple, Dict, List
import re
import shutil

def parse_codebase(zip_path: str) -> Tuple[Dict, str]:
    """
    Parses a zipped codebase and returns:
    1. A structured dict representing the file/folder tree
    2. A Mermaid.js string representing a class-based ERD (for Python files)
    """
    if not os.path.exists(zip_path):
        raise FileNotFoundError(f"Zip file not found: {zip_path}")

    # Create temporary extraction directory
    tmp_dir = tempfile.mkdtemp(prefix="infera_")
    try:
        # Extract zip
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(tmp_dir)

        # Build file tree
        structure = scan_dir(tmp_dir)

        # Generate Mermaid ERD (only for Python classes)
        mermaid_erd = generate_mermaid_erd(tmp_dir)

        return structure, mermaid_erd

    finally:
        # Clean up extracted files after use
        shutil.rmtree(tmp_dir, ignore_errors=True)


def scan_dir(path: str) -> Dict:
    """
    Recursively scans a directory and returns a nested dict representing the folder structure.
    """
    tree = {}
    for entry in os.scandir(path):
        if entry.is_dir():
            tree[entry.name] = scan_dir(entry.path)
        else:
            tree[entry.name] = None
    return tree


def generate_mermaid_erd(path: str) -> str:
    """
    Generates a Mermaid class diagram string from Python classes in the codebase.
    Detects simple inheritance relationships.
    """
    class_pattern = re.compile(r"class\s+(\w+)(\((\w+)\))?:")
    classes = {}
    relationships: List[Tuple[str, str]] = []

    # Scan all Python files
    for root, dirs, files in os.walk(path):
        for file in files:
            if file.endswith(".py"):
                file_path = os.path.join(root, file)
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        match = class_pattern.match(line.strip())
                        if match:
                            class_name = match.group(1)
                            parent = match.group(3)
                            classes[class_name] = {"file": os.path.relpath(file_path, path)}
                            if parent:
                                relationships.append((parent, class_name))

    # Build Mermaid.js string
    mermaid_lines = ["classDiagram"]
    for cls in classes:
        mermaid_lines.append(f"    class {cls}")

    for parent, child in relationships:
        mermaid_lines.append(f"    {parent} <|-- {child}")

    return "\n".join(mermaid_lines)
